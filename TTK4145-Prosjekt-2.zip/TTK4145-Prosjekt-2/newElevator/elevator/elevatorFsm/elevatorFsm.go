package elevatorFsm

func ChangeToMaster() {
	//TODO
}

func ChangeToSlave() {
	//TODO
}
